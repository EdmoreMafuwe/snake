const IP = '135.23.222.131';
const PORT = 50542;
module.exports = {
  IP,
  PORT
};